/**
 * KamzBot - Clean starter with Pairing (Mode 2) support
 * - Uses Baileys v4 (adiwajshing/baileys)
 * - Features: basic commands, pairing-token flow which creates a separate auth folder and prints QR
 * - Designed to run both on Pterodactyl and GitHub Codespaces (TTY QR may not display in Actions)
 *
 * Instructions (short):
 * 1. npm install
 * 2. set OWNER_JID env var or edit OWNER constant
 * 3. node index.js
 * 4. As owner: send ".pair <label>" to bot (label optional) -> bot creates auth_shared_TOKEN folder and prints QR to terminal + sends QR image to owner chat
 * 5. Scan QR from your WhatsApp (Link a device) to save session files into that auth folder.
 * 6. When session files exist in auth_shared_TOKEN, other machines can copy that folder and use it as their auth (or owner can run additional instances using that auth dir).
 *
 * Note: This is NOT OTP. This is pairing via generating a session folder and QR for the owner to scan.
 */

const P = require('pino');
const qrcode = require('qrcode');
const qrcodeTerminal = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const { default: makeWASocket, useSingleFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@adiwajshing/baileys');
const express = require('express');

// CONFIG
const OWNER = process.env.OWNER_JID || '62812xxxxxxxx@s.whatsapp.net';
const BOT_NAME = process.env.BOT_NAME || 'KamzBot';
const SESSION_FILE = './auth_info.json';
const PREFIX = '.';

// ensure minimal DB files
const DB_DIR = './db';
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);
const DB_SHARED = path.join(DB_DIR, 'shared_sessions.json');
if (!fs.existsSync(DB_SHARED)) fs.writeFileSync(DB_SHARED, JSON.stringify({}));

// auth state for main bot
const { state, saveState } = useSingleFileAuthState(SESSION_FILE);

async function startMainBot() {
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({ logger: P({ level: 'silent' }), printQRInTerminal: true, auth: state, version });

  sock.ev.on('creds.update', saveState);

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      // print small QR in terminal
      qrcodeTerminal.generate(qr, { small: true });
      console.log('[MAIN BOT] QR generated (also printed small version above).');
    }
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error && lastDisconnect.error.output?.statusCode !== DisconnectReason.loggedOut);
      console.log('Main connection closed, reconnect?', shouldReconnect);
      if (shouldReconnect) startMainBot();
      else console.log('Main bot logged out. Remove', SESSION_FILE, 'and restart.');
    }
    if (connection === 'open') console.log('Main bot connected.');
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (!msg.message) continue;
      if (msg.key && msg.key.remoteJid === 'status@broadcast') continue;
      await handleMessage(sock, msg).catch(console.error);
    }
  });

  return sock;
}

async function handleMessage(sock, msg) {
  const from = msg.key.remoteJid;
  const text = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').trim();
  if (!text) return;

  // only basic commands included to keep file stable
  if (!text.startsWith(PREFIX)) return;
  const args = text.slice(PREFIX.length).trim().split(/ +/);
  const cmd = args.shift().toLowerCase();

  // owner check (simple)
  const sender = msg.key.participant || msg.key.remoteJid;
  const isOwner = sender && sender.includes((OWNER||'').replace('@s.whatsapp.net',''));

  switch (cmd) {
    case 'start':
      await sock.sendMessage(from, { text: `Halo! Saya ${BOT_NAME}. Owner: ${OWNER}` });
      break;

    case 'menu':
      await sock.sendMessage(from, { text: `.pair <label> - create pairing session (owner only)\n.pairs - list shared sessions\n.info <token> - get info` });
      break;

    case 'pair':
      if (!isOwner) return await sock.sendMessage(from, { text: 'Owner only.' });
      await cmdCreatePair(sock, from, args.join(' ') || 'no-label');
      break;

    case 'pairs':
      await cmdListPairs(sock, from);
      break;

    case 'info':
      await cmdInfo(sock, from, args[0]);
      break;

    default:
      await sock.sendMessage(from, { text: `Perintah tidak dikenal: ${cmd}. Ketik .menu` });
  }
}

// Create pairing session: makes auth_shared_<TOKEN>, spawns temporary socket that saves creds there and prints QR + sends QR image
async function cmdCreatePair(sock, to, label) {
  try {
    const token = 'KAMZ-' + Math.random().toString(36).substring(2,10).toUpperCase();
    const authDir = `./auth_shared_${token}`;
    if (!fs.existsSync(authDir)) fs.mkdirSync(authDir);

    // create a single-file auth state in that dir
    const { useSingleFileAuthState } = require('@adiwajshing/baileys');
    const { state: adminState, saveState: saveAdminState } = useSingleFileAuthState(path.join(authDir, 'auth_info.json'));

    // spawn a temporary socket to print QR and save auth into authDir when scanned
    const { default: makeSocket } = require('@adiwajshing/baileys');
    const { fetchLatestBaileysVersion, DisconnectReason } = require('@adiwajshing/baileys');
    const ver = (await fetchLatestBaileysVersion()).version;

    const adminSock = makeSocket({ logger: P({ level: 'silent' }), printQRInTerminal: false, auth: adminState, version: ver });

    adminSock.ev.on('creds.update', saveAdminState);

    adminSock.ev.on('connection.update', async (u) => {
      const { qr, connection, lastDisconnect } = u;
      if (qr) {
        // send QR image to owner chat and print small QR to terminal
        qrcodeTerminal.generate(qr, { small: true });
        // convert to data URL and send as image
        qrcode.toDataURL(qr, (err, url) => {
          if (!err) {
            const b64 = url.split(',')[1];
            const buf = Buffer.from(b64, 'base64');
            adminSock.sendMessage(to, { image: buf, caption: `Pairing QR for token ${token} (label: ${label}) — scan with WhatsApp Link a device.` }).catch(()=>{});
          }
        });
      }
      if (connection === 'open') {
        // pairing successful; save metadata
        const db = JSON.parse(fs.readFileSync(DB_SHARED));
        db[token] = { token, label, created: new Date().toISOString(), authDir };
        fs.writeFileSync(DB_SHARED, JSON.stringify(db, null, 2));
        await adminSock.sendMessage(to, { text: `Pairing complete for token ${token}. Session saved in ${authDir}.` });
        // keep this adminSock running so the new session remains active in this process
      }
      if (connection === 'close') {
        const shouldReconnect = (lastDisconnect?.error && lastDisconnect.error.output?.statusCode !== DisconnectReason.loggedOut);
        if (!shouldReconnect) {
          // fully logged out; notify owner
          adminSock.sendMessage(to, { text: `Admin socket for ${token} logged out.` }).catch(()=>{});
        }
      }
    });

    await sock.sendMessage(to, { text: `Pair token created: ${token}. QR dikirim ke chat owner. Label: ${label}` });
  } catch (e) {
    console.error('cmdCreatePair error', e);
    await sock.sendMessage(to, { text: 'Gagal membuat pair: ' + e.message });
  }
}

async function cmdListPairs(sock, to) {
  try {
    const db = JSON.parse(fs.readFileSync(DB_SHARED));
    const keys = Object.keys(db);
    if (!keys.length) return await sock.sendMessage(to, { text: 'No pairs found.' });
    let txt = 'Pairs:\\n';
    for (const k of keys) {
      const it = db[k];
      txt += `${k} — ${it.label} — ${it.created}\\n`;
    }
    await sock.sendMessage(to, { text: txt });
  } catch (e) {
    console.error('cmdListPairs', e);
    await sock.sendMessage(to, { text: 'Error reading pairs.' });
  }
}

async function cmdInfo(sock, to, token) {
  try {
    if (!token) return await sock.sendMessage(to, { text: 'Usage: .info <token>' });
    const db = JSON.parse(fs.readFileSync(DB_SHARED));
    const it = db[token];
    if (!it) return await sock.sendMessage(to, { text: 'Token not found.' });
    await sock.sendMessage(to, { text: `Token: ${token}\\nLabel: ${it.label}\\nCreated: ${it.created}\\nAuthDir: ${it.authDir}` });
  } catch (e) {
    console.error('cmdInfo', e);
    await sock.sendMessage(to, { text: 'Error.' });
  }
}

// Start services: main bot + optional lightweight express server to show status/QR images
async function main() {
  const mainSock = await startMainBot();
  console.log('Main bot started.');

  // optional express server for status
  const app = express();
  app.get('/', (req, res) => res.send(`<h3>${BOT_NAME} running</h3><p>Owner: ${OWNER}</p>`));
  app.listen(process.env.PORT || 3000, () => console.log('Web status running on port', process.env.PORT || 3000));
}

main().catch(e => { console.error(e); process.exit(1); });
