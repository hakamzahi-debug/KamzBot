KamzBot Mode2 - Pairing flow (Mode 2)
Run (Pterodactyl / GitHub Codespaces):
1. npm install
2. set OWNER_JID env var or edit index.js
3. node index.js
4. From owner WhatsApp, send message to the bot: .pair mylabel
5. The bot will create an auth_shared_TOKEN folder and send a QR image to the owner chat. Scan that QR with WhatsApp > Link a device.
6. After scan completes, session files are stored in auth_shared_TOKEN. You can copy that folder to other instances to reuse the session.
Notes:
- This avoids scanning the main bot QR by creating a separate session for the paired device.
- Keep auth_shared folders private; anyone with them can control the session.
